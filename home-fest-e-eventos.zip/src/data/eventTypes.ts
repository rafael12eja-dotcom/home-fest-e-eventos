export type Section = {
  title: string;
  items: string[];
};

export type EventType = {
  id: string;           // usado como âncora/hash
  title: string;
  excerpt: string;      // texto curto do card
  image: string;        // arquivo em /public
  intro: string;        // parágrafo inicial do modal
  sections: Section[];  // acordeões
};

export const EVENT_TYPES: EventType[] = [
  {
    id: "infantil",
    title: "Buffet Infantil",
    excerpt:
      "Festa temática com decoração inclusa e cardápio infantil que agrada adultos e crianças.",
    // Utiliza a imagem de portfólio com prefixo para evitar conflito com serviços
    image: "portfolio-infantil.jpg",
    intro:
      "Nosso buffet infantil combina brincadeiras, cardápio pensado para os pequenos e apresentação caprichada para os adultos.",
    sections: [
      {
        title: "Bebidas",
        items: [
          "Refrigerantes, sucos e água à vontade",
          "Estação de refrescos gelados",
          "Opção de bebidas quentes (chocolate/achocolatado)"
        ],
      },
      {
        title: "Salgados e petiscos",
        items: [
          "Mini-hambúrguer, mini-dog, nuggets e batata smiles",
          "Pão de queijo, mini pizza, pastéis variados",
          "Mesa de frutas (opcional)",
        ],
      },
      {
        title: "Doces",
        items: [
          "Brigadeiro, beijinho e casadinho",
          "Cupcakes temáticos (opcional)",
          "Bolo confeitado (tamanho conforme número de convidados)",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Equipe de atendimento uniformizada",
          "Utensílios, guardanapos e itens de serviço",
          "Montagem/limpeza do espaço utilizado",
        ],
      },
    ],
  },
  {
    id: "15anos",
    title: "15 Anos",
    excerpt:
      "Produção completa para debutantes com cardápio elegante e serviço impecável.",
    image: "portfolio-15anos.jpg",
    intro:
      "Da recepção à mesa de doces, entregamos sofisticação com fluidez de serviço e apresentação premium.",
    sections: [
      {
        title: "Bebidas",
        items: [
          "Água, refrigerantes e sucos à vontade",
          "Coquetéis sem álcool",
          "Bar com drinks autorais (opcional)",
        ],
      },
      {
        title: "Finger foods & empratados",
        items: [
          "Bruschettas, mini tartines e vol-au-vent",
          "Massa ou risoto finalizados ao vivo (opcional)",
          "Ilhas gastronômicas personalizadas",
        ],
      },
      {
        title: "Mesa de doces",
        items: [
          "Doces finos assortidos",
          "Bolo temático (opcional)",
          "Bem-casado/bem-vivido (opcional)",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Equipe completa de atendimento",
          "Louça/utensílios de serviço",
          "Montagem, operação e limpeza do espaço utilizado",
        ],
      },
    ],
  },
  {
    id: "casamento",
    title: "Casamento",
    excerpt:
      "Cardápio autoral com apresentação refinada para cerimônias e recepções.",
    image: "portfolio-casamento.jpg",
    intro:
      "Cozinha afetiva com técnica, pensada para encantar em cada etapa da recepção do seu casamento.",
    sections: [
      {
        title: "Ilhas & entradas",
        items: [
          "Tábuas de queijos e charcutaria",
          "Estação de antepastos e pães artesanais",
          "Finger foods quentes e frios circulantes",
        ],
      },
      {
        title: "Pratos principais",
        items: [
          "Massa ou risoto finalizado na hora",
          "Carne/branco com molhos especiais",
          "Opção vegetariana/vegana sob consulta",
        ],
      },
      {
        title: "Bebidas",
        items: [
          "Água, refrigerantes e sucos",
          "Whisky, espumante e vinhos (opcional)",
          "Bar de drinks autorais (opcional)",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Mise en place e operação completa",
          "Coordenação gastronômica do evento",
          "Equipe uniformizada e limpeza do espaço utilizado",
        ],
      },
    ],
  },
  {
    id: "churrasco",
    title: "Churrasco",
    excerpt:
      "Cortes selecionados com guarnições e atendimento contínuo à la rodízio.",
    image: "portfolio-churrasco.jpg",
    intro:
      "Experiência de churrasco com variedade de cortes e guarnições, serviço fluido e estação de saladas.",
    sections: [
      {
        title: "Carnes",
        items: [
          "Picanha, fraldinha, linguiça artesanal",
          "Frango temperado e cortes suínos",
          "Opções adicionais sob consulta (cupim, costela etc.)",
        ],
      },
      {
        title: "Guarnições & saladas",
        items: [
          "Arroz, farofa especial e vinagrete",
          "Batatas rústicas/maionese",
          "Folhas, legumes e molhos da casa",
        ],
      },
      {
        title: "Bebidas",
        items: [
          "Água e refrigerantes à vontade",
          "Cerveja do cliente sem taxa; chope opcional",
          "Caipirinhas e drinks (opcional)",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Churrasqueiro e equipe de apoio",
          "Chapas, grelhas e utensílios",
          "Montagem e limpeza do espaço utilizado",
        ],
      },
    ],
  },
  {
    id: "boteco",
    title: "Comida de Boteco",
    excerpt:
      "Petiscos com apresentação elegante, tradição e sabor em clima descontraído.",
    image: "portfolio-boteco.jpg",
    intro:
      "Comida de boteco com toque gourmet, unindo tradição e sofisticação em petiscos irresistíveis.",
    sections: [
      {
        title: "Bebidas",
        items: [
          "Refrigerantes e água à vontade",
          "Cerveja do cliente sem taxa",
          "Chope opcional",
          "Caipirinhas e drinks",
        ],
      },
      {
        title: "Petiscos",
        items: [
          "Bolinho de bacalhau e croquete de carne",
          "Torresmo, linguiça artesana e mandioca",
          "Pastéis variados e mini porções quentes",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Equipe de atendimento",
          "Utensílios e montagem",
          "Limpeza do espaço utilizado",
        ],
      },
    ],
  },
  {
    id: "empresas",
    title: "Corporativo",
    excerpt:
      "Soluções para eventos de empresa com serviço executivo e cronograma enxuto.",
    image: "portfolio-empresas.jpg",
    intro:
      "Coffee, brunch ou coquetel corporativo com cardápios moduláveis, pontualidade e apresentação executiva.",
    sections: [
      {
        title: "Formatos",
        items: [
          "Coffee break, brunch, coquetel volante",
          "Almoço executivo (sob consulta)",
          "Montagem silenciosa e discreta",
        ],
      },
      {
        title: "Cardápio",
        items: [
          "Salgados assados e folhados finos",
          "Finger foods frios e quentes",
          "Mesa de frutas e doces (opcional)",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Equipe uniformizada e coordenação",
          "Utensílios, montagem e limpeza do espaço utilizado",
          "Relatórios e adequação a agenda do cliente",
        ],
      },
    ],
  },
  {
    id: "escolar",
    title: "Festa Escolar",
    excerpt:
      "Opção econômica e organizada para escolas, com cardápio infantil e logística simples.",
    image: "portfolio-escolar.jpg",
    intro:
      "Pacote pensado para escolas: serviço ágil, cardápio infantil e montagem prática.",
    sections: [
      {
        title: "Bebidas",
        items: [
          "Água e sucos",
          "Refrigerantes (opcional)",
        ],
      },
      {
        title: "Lanches",
        items: [
          "Mini sanduíches e assados",
          "Frutas em cubos/espeto",
          "Docinhos tradicionais",
        ],
      },
      {
        title: "Serviços inclusos",
        items: [
          "Equipe e utensílios",
          "Montagem e limpeza do espaço utilizado",
          "Ajuste de horários da instituição",
        ],
      },
    ],
  },
];
