import React from "react";

/**
 * Seção "Sobre Nós".
 *
 * Esta versão remove referências externas e citações e descreve de forma clara
 * e envolvente como a Home Fest & Eventos transforma qualquer celebração em
 * uma experiência gastronômica memorável. Mantém-se o foco na combinação de
 * técnicas refinadas, ingredientes selecionados e serviço impecável, além de
 * reforçar o compromisso com cardápios personalizados e apresentações
 * primorosas.
 */
export default function About() {
  return (
    <section id="sobre" className="bg-white py-16 md:py-24 px-5 md:px-8">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-10">
        {/* Imagem ilustrativa */}
        <div className="md:w-1/2 w-full">
          {/* Substituímos a imagem de "Sobre nós" para usar about.jpg enviada pelo cliente */}
          <img
            src="/about.jpg"
            alt="Equipe Home Fest & Eventos em um momento especial"
            className="w-full h-auto rounded-2xl shadow-xl object-cover"
          />
        </div>
        {/* Texto */}
        <div className="md:w-1/2 w-full">
          <h2 className="font-serif text-4xl md:text-5xl text-[#111] mb-4">
            Sobre nós
          </h2>
          <p className="text-lg md:text-xl text-neutral-700 leading-relaxed">
            A Home Fest & Eventos transforma cada celebração em uma experiência
            gastronômica única. Combinamos técnicas refinadas, ingredientes
            selecionados e um serviço impecável para encantar seus convidados do
            início ao fim. Seja em eventos intimistas ou grandes produções, nossa
            missão é elevar cada momento a um novo patamar, proporcionando
            memórias sensoriais inesquecíveis.
          </p>
          <p className="mt-4 text-lg md:text-xl text-neutral-700 leading-relaxed">
            Nosso compromisso é criar cardápios personalizados que unem sabor,
            sofisticação e apresentação primorosa — garantindo que seu evento
            seja lembrado por todos.
          </p>
        </div>
      </div>
    </section>
  );
}