import React, { useState } from "react";

type QA = {
  q: string;
  a: string;
};

const faqs: QA[] = [
  {
    q: "Com quanto tempo de antecedência devo fazer a reserva?",
    a: "Recomendamos 60 a 90 dias para garantir data e estrutura. Em alta temporada (mesversários/volta às aulas/férias/novembro-dezembro), quanto antes, melhor."
  },
  {
    q: "Vocês atendem em quais regiões?",
    a: "Belo Horizonte e região metropolitana. Para outras cidades, avaliamos logística e possível taxa de deslocamento."
  },
  {
    q: "É possível personalizar o cardápio?",
    a: "Sim. Partimos do cardápio base e ajustamos conforme perfil do evento, restrições, preferências e orçamento."
  },
  {
    q: "Crianças de 0 a 5 anos pagam?",
    a: "Não consideramos como convidados pagantes até 5 anos e 11 meses, salvo exceções específicas acordadas no contrato."
  }
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpen((curr) => (curr === idx ? null : idx));
  };

  return (
    <section id="faq" className="bg-[#FFF9F0] py-16 md:py-24 px-5 md:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Título */}
        <h2 className="font-serif text-center text-4xl md:text-5xl text-[#111]">
          Perguntas Frequentes
        </h2>
        <p className="text-center text-lg text-[#404040] mt-2 mb-10">
          Tire suas dúvidas sobre nossos serviços
        </p>

        {/* Accordion */}
        <div className="space-y-4">
          {faqs.map((item, idx) => {
            const isOpen = open === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-white ring-1 ring-black/5 shadow-[0_8px_26px_-14px_rgba(0,0,0,.18)]"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full flex items-center justify-between gap-4 text-left px-5 md:px-6 py-4 md:py-5"
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${idx}`}
                >
                  <span className="text-[17px] md:text-[18px] font-medium text-[#111]">
                    {item.q}
                  </span>

                  <svg
                    className={`shrink-0 transition-transform duration-200 ${
                      isOpen ? "rotate-180" : "rotate-0"
                    }`}
                    width="22"
                    height="22"
                    viewBox="0 0 24 24"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M6 9l6 6 6-6"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>

                <div
                  id={`faq-panel-${idx}`}
                  className={`${isOpen ? "block" : "hidden"} px-5 md:px-6 pb-5 md:pb-6 text-[#3a3a3a] leading-relaxed`}
                >
                  {item.a}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
