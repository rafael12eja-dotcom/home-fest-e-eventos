import React from "react";

export default function FinalCTA() {
  return (
    <section
      id="contato"
      className="bg-[#FBF6EE] py-20 md:py-28 px-5 md:px-8 border-t border-[#e9e1d6]"
    >
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="font-serif text-4xl md:text-5xl text-[#111] mb-4">
          Entre em contato
        </h2>
        <p className="text-[#555] text-lg md:text-xl leading-relaxed max-w-3xl mx-auto mb-10">
          Fale conosco pelo WhatsApp ou redes sociais e transforme seu evento em uma
          experiência gastronômica inesquecível. Estamos prontos para atender você
          com atenção, cuidado e dedicação.
        </p>
        <a
          href="https://wa.me/5531999186245"
          target="_blank"
          rel="noopener noreferrer"
          className="hf-btn hf-btn--primary text-lg md:text-xl px-9 py-4"
        >
          Solicitar orçamento no WhatsApp
        </a>
        <div className="mt-12 text-[#444] text-base md:text-lg leading-relaxed">
          <p>
            <strong>Telefone / WhatsApp:</strong>{" "}
            <a
              href="https://wa.me/5531999186245"
              className="underline underline-offset-4 decoration-[#c19a4a] hover:text-[#c19a4a]"
            >
              (31) 99918-6245
            </a>
          </p>
          <p className="mt-2">
            <strong>Instagram:</strong>{" "}
            <a
              href="https://instagram.com/homefesteventos"
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-4 decoration-[#c19a4a] hover:text-[#c19a4a]"
            >
              @homefesteventos
            </a>
          </p>
          <p className="mt-2">
            <strong>E-mail:</strong>{" "}
            <a
              href="mailto:contato@homefesteeventos.com.br"
              className="underline underline-offset-4 decoration-[#c19a4a] hover:text-[#c19a4a]"
            >
              contato@homefesteeventos.com.br
            </a>
          </p>
          <p className="mt-2">
            <strong>Facebook:</strong>{" "}
            <a
              href="https://facebook.com/homefesteventos"
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-4 decoration-[#c19a4a] hover:text-[#c19a4a]"
            >
              Home Fest e Eventos
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
