import React from "react";

/**
 * Lista de serviços oferecidos. Inspirado na seção de categorias
 * (CAFÉ DA MANHÃ, FINGER FOOD, COFFEE BREAK, ALMOÇO, JANTAR, CATERING) do site
 * de referência【868132981816042†L140-L161】, adaptamos os nomes e descrições para
 * o contexto da Home Fest & Eventos. Cada serviço possui uma imagem de
 * apoio disponível em /public.
 */
type Service = {
  id: string;
  title: string;
  description: string;
  image: string;
};

// A lista de serviços foi ajustada para utilizar as fotos fornecidas pelo cliente.
// Cada item aponta para um arquivo em /public correspondente.
const services: Service[] = [
  {
    id: "cafedamanha",
    title: "Café da Manhã",
    description:
      "Comece seu evento com energia: seleção de pães artesanais, frutas, sucos e bebidas quentes.",
    // Imagem específica de café da manhã fornecida pelo cliente
    image: "cafedamanha.jpg",
  },
  {
    id: "fingerfood",
    title: "Finger Food",
    description:
      "Petiscos sofisticados para receber seus convidados com charme e praticidade.",
    // Imagem de finger foods personalizada
    image: "fingerfood.jpg",
  },
  {
    id: "coffeebreak",
    title: "Coffee Break",
    description:
      "Intervalo perfeito: cafés, chás, lanches leves e guloseimas para recarregar as energias.",
    // Imagem corporativa para coffee break
    image: "coffeebreak.jpg",
  },
  {
    id: "almoco",
    title: "Almoço",
    description:
      "Pratos completos com proteínas, massas e guarnições para um almoço memorável.",
    // Churrasco como símbolo de almoço reforçado
    image: "almoco.jpg",
  },
  {
    id: "jantar",
    title: "Jantar",
    description:
      "Um banquete noturno com opções elegantes, harmonização de vinhos e sobremesas especiais.",
    // Imagem elegante de jantar fornecida
    image: "jantar.jpg",
  },
  {
    id: "catering",
    title: "Catering",
    description:
      "Estrutura completa para eventos sociais e corporativos em qualquer local: equipe, utensílios e cardápio personalizado.",
    // Imagem de catering fornecida pelo cliente
    image: "catering.jpg",
  },
];

export default function Services() {
  return (
    <section id="servicos" className="bg-[#FBF6EE] py-16 md:py-24 px-5 md:px-8">
      <div className="max-w-7xl mx-auto text-center">
        <h2 className="font-serif text-4xl md:text-5xl text-[#111]">
          Nossos Serviços
        </h2>
        <p className="text-lg text-[#404040] mt-2 mb-12">
          Cardápios e experiências para cada ocasião
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map((s) => (
            <div
              key={s.id}
              className="bg-white rounded-3xl overflow-hidden shadow-[0_10px_24px_-12px_rgba(0,0,0,.15)] ring-1 ring-black/5 hover:shadow-[0_16px_32px_-12px_rgba(0,0,0,.25)] transition"
            >
              <img
                src={`/${s.image}`}
                alt={s.title}
                className="w-full h-56 object-cover"
              />
              <div className="p-6 text-left">
                <h3 className="text-xl font-semibold text-neutral-900">
                  {s.title}
                </h3>
                <p className="mt-2 text-neutral-600 leading-relaxed">
                  {s.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}