import React from "react";

export default function Footer() {
  const year = new Date().getFullYear();

  // Navegação principal e lista de serviços para o novo layout
  const navMain = [
    { href: "#servicos", label: "Cardápio" },
    { href: "#sobre", label: "Sobre" },
    { href: "#portfolio", label: "Portfólio" },
    { href: "#depoimentos", label: "Depoimentos" },
    { href: "#contato", label: "Contato" },
  ];
  const navServices = [
    { href: "#cafedamanha", label: "Café da Manhã" },
    { href: "#fingerfood", label: "Finger Food" },
    { href: "#coffeebreak", label: "Coffee Break" },
    { href: "#almoco", label: "Almoço" },
    { href: "#jantar", label: "Jantar" },
    { href: "#catering", label: "Catering" },
  ];

  return (
    <footer className="bg-[#0B0B0C] text-[#EDE6DB] border-t border-[#C19A4A]/30">
      {/* Topo do footer */}
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Marca */}
          <div className="md:col-span-1">
            <a href="#topo" className="inline-flex items-center gap-3">
              {/* Garanta que /public/logo.png exista */}
              <img
                src="/logo.png"
                alt="Home Fest & Eventos"
                className="h-14 w-auto drop-shadow-[0_4px_18px_rgba(193,154,74,0.45)]"
              />
            </a>
            <p className="mt-4 text-sm/6 text-[#CFC8BC] max-w-xs">
              Experiências memoráveis com gastronomia autoral, serviço completo e
              curadoria de detalhes — do briefing ao brinde final.
            </p>

            <a
              href="https://wa.me/5531999186245"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex hf-btn hf-btn--primary"
            >
              Solicitar Orçamento
            </a>
          </div>

          {/* Navegação principal */}
          <div>
            <h4 className="font-serif text-xl text-white mb-4">Navegação</h4>
            <ul className="grid grid-cols-1 gap-2">
              {navMain.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="text-[#CFC8BC] hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Serviços */}
          <div>
            <h4 className="font-serif text-xl text-white mb-4">Serviços</h4>
            <ul className="grid grid-cols-1 gap-2">
              {navServices.map((item) => (
                <li key={item.href}>
                  <a
                    href={`#servicos`}
                    className="text-[#CFC8BC] hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h4 className="font-serif text-xl text-white mb-4">Contato</h4>
            <ul className="space-y-2 text-[#CFC8BC]">
              <li>
                <span className="text-white/90">WhatsApp:</span>{" "}
                <a
                  href="https://wa.me/5531999186245"
                  className="underline underline-offset-4 decoration-[#C19A4A] hover:text-white"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  (31) 99918-6245
                </a>
              </li>
              <li>
                <span className="text-white/90">Instagram:</span>{" "}
                <a
                  href="https://instagram.com/homefesteventos"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline underline-offset-4 decoration-[#C19A4A] hover:text-white"
                >
                  @homefesteventos
                </a>
              </li>
              <li>
                <span className="text-white/90">E-mail:</span>{" "}
                <a
                  href="mailto:contato@homefesteeventos.com.br"
                  className="underline underline-offset-4 decoration-[#C19A4A] hover:text-white"
                >
                  contato@homefesteeventos.com.br
                </a>
              </li>
              <li>
                <span className="text-white/90">Facebook:</span>{" "}
                <a
                  href="https://facebook.com/homefesteventos"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline underline-offset-4 decoration-[#C19A4A] hover:text-white"
                >
                  Home Fest e Eventos
                </a>
              </li>
              <li className="pt-2">
                <p className="text-sm">
                  Atendimento em BH e região metropolitana. Orçamentos sob
                  consulta para outras cidades.
                </p>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Barra inferior */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#CFC8BC]">
            © {year} Home Fest &amp; Eventos — Todos os direitos reservados.
          </p>

          <div className="flex items-center gap-4 text-xs text-[#CFC8BC]">
            <a
              href="#servicos"
              className="hover:text-white transition-colors underline underline-offset-4 decoration-[#C19A4A]"
            >
              Cardápio
            </a>
            <span className="opacity-40">•</span>
            <a
              href="#contato"
              className="hover:text-white transition-colors underline underline-offset-4 decoration-[#C19A4A]"
            >
              Fale conosco
            </a>
            <span className="opacity-40">•</span>
            <a
              href="#topo"
              className="hover:text-white transition-colors underline underline-offset-4 decoration-[#C19A4A]"
            >
              Voltar ao topo
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
