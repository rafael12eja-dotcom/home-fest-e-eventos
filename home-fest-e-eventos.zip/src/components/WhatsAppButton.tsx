const WhatsAppButton = () => (
  <a
    href="https://wa.me/5531999186245"
    target="_blank"
    rel="noreferrer"
    className="fixed bottom-6 right-6 btn-primary shadow-2xl"
  >
    WhatsApp
  </a>
)
export default WhatsAppButton
